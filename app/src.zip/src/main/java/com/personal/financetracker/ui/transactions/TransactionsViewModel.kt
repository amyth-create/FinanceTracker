package com.personal.financetracker.ui.transactions

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.personal.financetracker.data.AppDatabase
import com.personal.financetracker.data.Repository
import com.personal.financetracker.data.Transaction
import kotlinx.coroutines.launch

class TransactionsViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = Repository(AppDatabase.getDatabase(app))

    val transactions = repo.getAllTransactions().asLiveData()

    fun delete(transaction: Transaction) {
        viewModelScope.launch { repo.deleteTransaction(transaction) }
    }
}
