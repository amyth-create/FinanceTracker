package com.personal.financetracker.ui.reports

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.personal.financetracker.databinding.FragmentReportsBinding
import com.personal.financetracker.util.Formatters

class ReportsFragment : Fragment() {

    private var _binding: FragmentReportsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ReportsViewModel by viewModels()

    private var showingExpenses = true

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentReportsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupChart()

        binding.toggleExpenses.setOnClickListener { showingExpenses = true; refreshChart() }
        binding.toggleIncome.setOnClickListener { showingExpenses = false; refreshChart() }

        viewModel.allTransactions.observe(viewLifecycleOwner) { txs ->
            val income = txs.filter { it.type == "income" }.sumOf { it.amount }
            val expense = txs.filter { it.type == "expense" }.sumOf { it.amount }
            val balance = income - expense
            val savingsRate = if (income > 0) ((income - expense) / income * 100) else 0.0

            binding.tvTotalIncome.text = Formatters.formatAmount(income)
            binding.tvTotalExpense.text = Formatters.formatAmount(expense)
            binding.tvNetBalance.text = Formatters.formatAmount(balance)
            binding.tvSavingsRate.text = if (income > 0) "%.1f%%".format(savingsRate) else "—"
        }

        viewModel.monthTransactions.observe(viewLifecycleOwner) { txs ->
            val income = txs.filter { it.type == "income" }.sumOf { it.amount }
            val expense = txs.filter { it.type == "expense" }.sumOf { it.amount }
            binding.tvMonthIncome.text = Formatters.formatAmount(income)
            binding.tvMonthExpense.text = Formatters.formatAmount(expense)
            binding.tvMonthNet.text = Formatters.formatAmount(income - expense)
            binding.tvMonthLabel.text = "${Formatters.currentMonthLabel()} Snapshot"

            // Category breakdown
            val type = if (showingExpenses) "expense" else "income"
            val catTotals = txs.filter { it.type == type }
                .groupBy { it.categoryName }
                .map { (name, items) ->
                    Triple(name,
                        items.first().categoryEmoji,
                        items.sumOf { it.amount })
                }
                .sortedByDescending { it.third }
            val total = catTotals.sumOf { it.third }
            buildCategoryBreakdown(catTotals, total)
        }

        viewModel.last6Months.observe(viewLifecycleOwner) { updateChart(it) }
    }

    private fun setupChart() {
        binding.barChart.apply {
            setDrawGridBackground(false)
            description.isEnabled = false
            legend.isEnabled = false
            setScaleEnabled(false)
            setBackgroundColor(Color.parseColor("#13131A"))
            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                setDrawGridLines(false)
                textColor = Color.parseColor("#8A8799")
                textSize = 10f
                granularity = 1f
            }
            axisLeft.apply {
                setDrawGridLines(true)
                gridColor = Color.parseColor("#1F1F2E")
                textColor = Color.parseColor("#8A8799")
                axisMinimum = 0f
            }
            axisRight.isEnabled = false
            animateY(600)
        }
    }

    private var lastMonths: List<MonthData> = emptyList()

    private fun refreshChart() {
        if (lastMonths.isNotEmpty()) updateChart(lastMonths)
    }

    private fun updateChart(months: List<MonthData>) {
        lastMonths = months
        val color = if (showingExpenses) Color.parseColor("#FF5C7A") else Color.parseColor("#2DD4A0")
        val entries = months.mapIndexed { i, m ->
            BarEntry(i.toFloat(), (if (showingExpenses) m.expense else m.income).toFloat())
        }
        val dataSet = BarDataSet(entries, "").apply {
            this.color = color
            valueTextColor = Color.TRANSPARENT
        }
        binding.barChart.apply {
            data = BarData(dataSet).apply { barWidth = 0.6f }
            xAxis.valueFormatter = IndexAxisValueFormatter(months.map { it.label })
            invalidate()
        }
    }

    private fun buildCategoryBreakdown(
        cats: List<Triple<String, String, Double>>,
        total: Double
    ) {
        binding.llCategories.removeAllViews()
        if (cats.isEmpty()) return
        cats.forEach { (name, emoji, amount) ->
            val pct = if (total > 0) (amount / total * 100) else 0.0
            val row = layoutInflater.inflate(
                com.personal.financetracker.R.layout.item_category_stat,
                binding.llCategories,
                false
            )
            row.findViewById<android.widget.TextView>(com.personal.financetracker.R.id.tv_emoji).text = emoji
            row.findViewById<android.widget.TextView>(com.personal.financetracker.R.id.tv_name).text = name
            row.findViewById<android.widget.TextView>(com.personal.financetracker.R.id.tv_amount).text = Formatters.formatAmount(amount)
            row.findViewById<android.widget.TextView>(com.personal.financetracker.R.id.tv_pct).text = "%.1f%%".format(pct)
            val bar = row.findViewById<View>(com.personal.financetracker.R.id.view_bar)
            bar.post { bar.layoutParams.width = ((bar.parent as View).width * pct / 100).toInt(); bar.requestLayout() }
            binding.llCategories.addView(row)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
