package com.personal.financetracker.ui.transactions

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.personal.financetracker.R
import com.personal.financetracker.data.Transaction
import com.personal.financetracker.databinding.FragmentTransactionsBinding
import com.personal.financetracker.util.Formatters
import java.io.File

class TransactionsFragment : Fragment() {

    private var _binding: FragmentTransactionsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: TransactionsViewModel by viewModels()
    private lateinit var adapter: TransactionAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentTransactionsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = TransactionAdapter(
            showDelete = true,
            onDelete = { tx -> confirmDelete(tx) },
            onClick = { tx ->
                val bundle = Bundle().apply { putLong("transactionId", tx.id) }
                findNavController().navigate(R.id.action_transactions_to_add, bundle)
            }
        )
        binding.rvTransactions.layoutManager = LinearLayoutManager(requireContext())
        binding.rvTransactions.adapter = adapter

        binding.btnExport.setOnClickListener { exportToCsv() }

        binding.fabAdd.setOnClickListener {
            findNavController().navigate(R.id.action_transactions_to_add)
        }

        var currentFilter = "all"

        fun applyFilter(filter: String) {
            currentFilter = filter
            binding.chipAll.isChecked = filter == "all"
            binding.chipExpense.isChecked = filter == "expense"
            binding.chipIncome.isChecked = filter == "income"
            viewModel.transactions.value?.let { txs ->
                val filtered = when (filter) {
                    "income" -> txs.filter { it.type == "income" }
                    "expense" -> txs.filter { it.type == "expense" }
                    else -> txs
                }
                adapter.submitList(filtered)
                binding.tvCount.text = "${filtered.size} transaction${if (filtered.size != 1) "s" else ""}"
                binding.emptyState.visibility = if (filtered.isEmpty()) View.VISIBLE else View.GONE
            }
        }

        binding.chipAll.setOnClickListener { applyFilter("all") }
        binding.chipExpense.setOnClickListener { applyFilter("expense") }
        binding.chipIncome.setOnClickListener { applyFilter("income") }

        viewModel.transactions.observe(viewLifecycleOwner) { _ ->
            applyFilter(currentFilter)
        }
    }

    private fun exportToCsv() {
        val transactions = viewModel.transactions.value ?: return
        if (transactions.isEmpty()) {
            Toast.makeText(requireContext(), "No data to export", Toast.LENGTH_SHORT).show()
            return
        }

        val csvHeader = "Date,Type,Amount,Category,Note\n"
        val csvData = transactions.joinToString("\n") { tx ->
            "${Formatters.formatDate(tx.date)},${tx.type},${tx.amount},${tx.categoryName},${tx.note.replace(",", " ")}"
        }
        val csvContent = csvHeader + csvData

        try {
            val fileName = "finance_transactions.csv"
            val file = File(requireContext().cacheDir, fileName)
            file.writeText(csvContent)

            val uri = FileProvider.getUriForFile(requireContext(), "com.personal.financetracker.provider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "Export CSV"))
        } catch (e: Exception) {
            Toast.makeText(requireContext(), "Export failed: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun confirmDelete(tx: Transaction) {
        AlertDialog.Builder(requireContext())
            .setTitle("Delete transaction?")
            .setMessage("This cannot be undone.")
            .setPositiveButton("Delete") { _, _ -> viewModel.delete(tx) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
