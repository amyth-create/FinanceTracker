package com.personal.financetracker.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.personal.financetracker.R
import com.personal.financetracker.databinding.FragmentDashboardBinding
import com.personal.financetracker.ui.transactions.TransactionAdapter
import com.personal.financetracker.util.Formatters

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!
    private val viewModel: DashboardViewModel by viewModels()
    private lateinit var adapter: TransactionAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = TransactionAdapter(
            showDelete = false,
            onDelete = {},
            onClick = { tx ->
                val bundle = Bundle().apply { putLong("transactionId", tx.id) }
                findNavController().navigate(R.id.action_dashboard_to_add, bundle)
            }
        )
        binding.rvRecent.layoutManager = LinearLayoutManager(requireContext())
        binding.rvRecent.adapter = adapter

        binding.fabAdd.setOnClickListener {
            findNavController().navigate(R.id.action_dashboard_to_add)
        }

        binding.tvSeeAll.setOnClickListener {
            findNavController().navigate(R.id.transactions)
        }

        observeData()
    }

    private fun observeData() {
        viewModel.totalBalance.observe(viewLifecycleOwner) { balance ->
            val b = balance ?: 0.0
            binding.tvBalance.text = Formatters.formatAmount(b)
            binding.tvBalance.setTextColor(
                ContextCompat.getColor(requireContext(),
                    if (b >= 0) R.color.income else R.color.expense)
            )
        }

        viewModel.allTransactions.observe(viewLifecycleOwner) { txs ->
            val income = txs.filter { it.type == "income" }.sumOf { it.amount }
            val expense = txs.filter { it.type == "expense" }.sumOf { it.amount }
            binding.tvTotalIncome.text = Formatters.formatAmount(income)
            binding.tvTotalExpense.text = Formatters.formatAmount(expense)
            // Show 8 most recent
            adapter.submitList(txs.take(8))
            binding.emptyState.visibility = if (txs.isEmpty()) View.VISIBLE else View.GONE
        }

        viewModel.monthTransactions.observe(viewLifecycleOwner) { txs ->
            val income = txs.filter { it.type == "income" }.sumOf { it.amount }
            val expense = txs.filter { it.type == "expense" }.sumOf { it.amount }
            binding.tvMonthIncome.text = Formatters.formatAmount(income)
            binding.tvMonthExpense.text = Formatters.formatAmount(expense)
            binding.tvMonthNet.text = Formatters.formatAmount(income - expense)
            binding.tvMonthName.text = Formatters.currentMonthLabel()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
