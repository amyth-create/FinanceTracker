package com.personal.financetracker.ui.dashboard

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.asLiveData
import com.personal.financetracker.data.AppDatabase
import com.personal.financetracker.data.Repository
import com.personal.financetracker.util.Formatters
import kotlinx.coroutines.flow.map

class DashboardViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = Repository(AppDatabase.getDatabase(app))

    val allTransactions = repo.getAllTransactions().asLiveData()

    val monthTransactions = repo.getTransactionsInRange(
        Formatters.startOfMonth(), Formatters.endOfMonth()
    ).asLiveData()

    val totalBalance = repo.getAllTransactions().map { txs ->
        val income = txs.filter { it.type == "income" }.sumOf { it.amount }
        val expense = txs.filter { it.type == "expense" }.sumOf { it.amount }
        income - expense
    }.asLiveData()
}
